import express from 'express';
import dotenv from 'dotenv';
import db from './config/db.js';
import feladatokRouter from './routes/feladatok.js';
import projektekRouter from './routes/projektek.js';

dotenv.config();

const app = express();
const port = process.env.PORT || 5000;

app.use(express.json());

// utvonalak
app.use('/api/feladatok', feladatokRouter);
app.use('/api/projektek', projektekRouter);

app.listen(port, () => {
  console.log(`Example app listening on port http://localhost:${port}`)
})