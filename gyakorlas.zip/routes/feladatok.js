import express from 'express';
import db from '../config/db.js';
const router = express.Router();


router.get('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const [rows] = await db.query(`SELECT * FROM feladatok WHERE id = ?`, [id]);
        
        if (rows.length === 0) {
            return res.status(404).json({ error: "Task not found" });
        }
        res.json(rows[0]);
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: "Internal server error" });
    }
});

router.put('/:id', async (req, res) => {
    try {
        const { id } = req.params; 
        const { feladat_neve, leiras, statusz, prioritas, hatarido, becsult_ido, felelos_neve } = req.body; 
        
        await db.query(
            `UPDATE feladatok SET feladat_neve = ?, leiras = ?, statusz = ?, prioritas = ?, hatarido = ?, becsult_ido = ?, felelos_neve = ? WHERE id = ?`, 
            [feladat_neve, leiras, statusz, prioritas, hatarido, becsult_ido, felelos_neve, id]
        );
        
        res.status(200).json({ message: "Sikeres frissites." });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: "Internal server error" });
    }
});


router.delete('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        await db.query(`DELETE FROM feladatok WHERE id = ?`, [id]);
        res.status(200).json({ message: "Succesful delete." });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: "Internal server error." });
    }
});

export default router;
