import express from 'express';
import db from '../config/db.js';
const router = express.Router();


router.get('/', async (req, res)=>{
    try {
        const [result] = await db.query(`SELECT * FROM projektek`);
        res.json(result);
    } catch (error) {
        console.error(error);
        res.status(500).json({error: "Internal server error."});
    }
});

router.get('/:projekt_id/feladatok', async (req, res) => {
    try {
        const { projekt_id } = req.params;
        const [rows] = await db.query(`SELECT feladat_neve FROM feladatok WHERE projekt_id = ?`, [projekt_id]);
        res.json(rows);
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: "Internal server error" });
    }
});

router.get('/:id', async (req, res)=>{
    try {
        const {id} = req.params;
        const [result] = await db.query(`SELECT * FROM projektek WHERE id = ?`, [id]);
        res.json(result);
    } catch (error) {
        console.error(error);
        res.status(500).json({error: "Internal server error."})
    }
});

router.post('/', async (req, res)=>{
    try {
        const {nev, leiras, kezdeti_datum, hatarido, befejezesi_datum, koltsegvetes, tulajdonos_neve} = req.body;
        const [res] = await db.query(`INSERT INTO projektek (nev, leiras, kezdeti_datum, hatarido, befejezesi_datum, koltsegvetes, tulajdonos_neve) VALUES (?,?,?,?,?,?,?)`);
        res.status(201).json({message: "Succesful insert."})
    } catch (error) {
        console.error(error);
        res.status(500).json({error: "Internal server error."})
    }
})

router.delete('/:id', async (req, res)=>{
    try {
        const {id} = req.params;
        const [result] = await db.query(`DELETE FROM projektek WHERE id = ?`, [id]);
        res.status(200).json({message: "Succesful delete."});
    } catch (error) {
        console.error(error);
        res.status(500).json({error: "Internal server error."})
    }
})

export default router;